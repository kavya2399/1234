package com.capg.javalab5;
import com.capg.javalab5.NameException;
public class UserDefiendExcep {
	
	public String checkname(String fname,String lname) throws Exception{
		
		try {
			if(!fname.isEmpty() || !lname.isEmpty()) {
			
			System.out.println(fname);
			System.out.println(lname);
			}
			
		}catch(Exception e) {
			throw new NameException("invalid name");
		}
		return fname;
	}
	
	public static void main(String[] args) throws Exception {
		String fname="sowndarya";
		String lname=null;
		UserDefiendExcep user=new UserDefiendExcep();
		user.checkname(fname,lname);
	}

}
