package com.cg.eis.service;

import java.util.ArrayList;
import java.util.List;

//import java.util.HashMap;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeInterface{
List<Employee> list=new ArrayList<>();

	
	@Override
	public Employee addEmp(Employee emp) {
		
		// TODO Auto-generated method stub
		//String Insurance;
		
		if(emp.getSalary()>5000 && emp.getSalary()< 20000 && emp.getDesignation().equalsIgnoreCase("System Associate")) {
			emp.setInsuranceScheme("Scheme C");
		}
		else if(emp.getSalary()>=20000 && emp.getSalary()< 40000 && emp.getDesignation().equalsIgnoreCase("Programmer")) {
			emp.setInsuranceScheme("Scheme B");
		}else if(emp.getSalary()>=40000  && emp.getDesignation().equalsIgnoreCase("Manager")) {
			emp.setInsuranceScheme("Scheme A");
		}else {
			emp.setInsuranceScheme("No Scheme");
		}
		
          list.add(emp);
       

		return emp;

}
}
